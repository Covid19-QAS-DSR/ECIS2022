from django.contrib import admin

# Register your models here.
from backend_app.models import Doc

admin.site.register(Doc)