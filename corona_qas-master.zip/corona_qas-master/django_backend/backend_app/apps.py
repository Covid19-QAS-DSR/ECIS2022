from django.apps import AppConfig


class BackendAppConfig(AppConfig):
    name = 'backend_app'
