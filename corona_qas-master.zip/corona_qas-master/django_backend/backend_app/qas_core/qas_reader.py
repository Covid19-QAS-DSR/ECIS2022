
class QASReader:
    def __init__(self, variant=None):
        self.__variant = variant

    def set_variant(self, variant):
        self.__variant = variant

    def initialize(self):
        pass
