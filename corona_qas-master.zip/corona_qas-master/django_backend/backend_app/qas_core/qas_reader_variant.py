from abc import ABC


class QASReaderVariant(ABC):
    def __init__(self):
        pass
