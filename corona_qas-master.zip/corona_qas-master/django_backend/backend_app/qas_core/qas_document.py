from haystack.database.base import Document


class QASDocument(Document):
    pass
